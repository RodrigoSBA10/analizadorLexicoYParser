package Analizadores;
/**
 * Parser Recursivo
 */
public class Parser {
  private Lexico lexico; // Analizador lexico, para recuperar los tokens
  private String tokenActual; // Token en el que esta
  
  /**
   * Contructor recibe el analizdor lexico y tomamos el primer token
   * @param lexico instancia de lexico
   */
  public Parser(Lexico lexico) {
	this.lexico = lexico;
	this.tokenActual = lexico.avanzaSiguienteToken();
  }
  
  /**
   * Para verificar si el token actual es el esperado y avanza al sigueinte si asi es
   * @param esperado token esperado
   */
  private void coincide(String esperado) {
    if (tokenActual.equals(esperado)) {
      tokenActual = lexico.avanzaSiguienteToken();
	} else {
      error("Error de sintaxis: se esperaba " + esperado + " pero se encontro " + tokenActual);
	}
  }
  
  /**
   * (programa) -> INICIO TAB (declaracion) (lista_enunciados) FIN
   */
  public void programa() {
    if (tokenActual.equals("Inicio")) {
		coincide("Inicio");
		coincide("TAB");
		declaracion();
		listaEnunciados();
		coincide("Fin");
	} else {
		error("Erro de sintaxis en <programa>");
	}
  }
  
  /**
   * (declaracion) -> id (lista_ids) ;
   */
  private void declaracion() {
	if (tokenActual.equals("id")) {
      coincide("id");
      listaIds();
      coincide(";");
	} else {
	  error("Error de sintaxis en <declaracion>");
	}
  }
  
  /**
   * (listas_ids) -> , id (listas_id) Es recursivo
   * (listas_ids) -> e
   */
  private void listaIds() {
    if (tokenActual.equals(",")) {
      coincide(",");
      coincide("id");
      listaIds();
	}
    // caso epsilon (e) : no hace nada.
  }
  
  /**
   * (lista_enunciados) -> TAB (enunciado) (fin_de_lista)
   */
  private void listaEnunciados() {
    if (tokenActual.equals("TAB")) {
      coincide("TAB");
      enunciado();
      finDeLista();
	}  
  }
  
  /**
   * (enunciado) ->
   */
  private void enunciado() {
    switch (tokenActual) {
	case "id": // -> id := (enunciado) (expresion);
      coincide("id");
	  coincide(":=");
	  expresion();
	  coincide(";");
		break;
	case "Leer": // -> Leer id;
		coincide("Leer");
		coincide("id");
		coincide(";");
		break;
	case "Escribir": // -> Escribir id;
		coincide("Escribir");
		coincide("id");
		coincide(";");
		break;
	case "Si": // -> Si (condicion) Entonces TAB (enunciado) (lista_enunciados) TAB Sino TAB (enunciado) (lista_enunciados) (fin_if)
		coincide("Si");
		condicion();
		coincide("Entonces");
		coincide("TAB");
		enunciado();
		listaEnunciados();
		coincide("TAB");
		coincide("Sino");
		coincide("TAB");
		enunciado();
		listaEnunciados();
		finIf();
		break;
	case "Mientras": // -> Mientras (condicion) Hacer TAB (enunciado) (lista_enunciados) TAB Fin
		coincide("Mientras");
		condicion();
		coincide("Hacer");
		coincide("TAB");
		enunciado();
		listaEnunciados();
		coincide("TAB");
		coincide("Fin");
		break;
   default:
		error("Error de sintaxis en <enunciado>");
	}
  }
  
  /**
   * (expresion) -> (termino) (expresion simple)
   */
  private void expresion() {
    termino();
    expresionSimple();
  }
  
  /**
   * (termino) -> (factor) (termino simple)
   */
  private void termino() {
    factor();
    terminoSimple();
  }
  
  /**
   * (factor) ->
   */
  private void factor() {
    switch (tokenActual) {
	case "(": // -> ( <expresion> )
		coincide("(");
		expresion();
	    coincide(")");
		break;
	case "id": // -> id
		coincide("id");
		break;
	case "entero": // -> entero
		coincide("entero");
		break;
	default:
		error("Error de sintaxis en <factor>");
	}
  }
  
  /**
   * (fin_de_lista) -> TAB (enunciado) (fin_de_lista)
   */
  private void finDeLista() {
    if (tokenActual.equals("TAB")) {
      coincide("TAB");
      enunciado();
      finDeLista();
	}
    // cuando es epsilon (e) no hace nada
  }
  
  /**
   * (condicion) -> (factor) (op rel) (factor)
   */
  private void condicion() {
    factor();
    opRel();
    factor();
  }
  
  /** 
   * (op rel) -> > || (op rel) -> < || (op rel) -> EQ || (op rel) -> LE || (op rel) -> GE
   */
  private void opRel() {
    if (tokenActual.equals(">") || tokenActual.equals("<") ||
        tokenActual.equals("EQ") || tokenActual.equals("LE") || tokenActual.equals("GE")) {
		coincide(tokenActual);
	} else {
		error("Error de sintaxis en <op rel>");
	}
  }
  
  /**
   * (fin_if) ->
   */
  private void finIf() {
    if (tokenActual.equals("Fin")) { // -> fin
      coincide("Fin");
	} else if (tokenActual.equals("Sino")) { // -> Sino TAB (enunciado) (lista_enunciados) TAB Fin
	  coincide("Sino");
	  coincide("TAB");
	  enunciado();
	  listaEnunciados();
	  coincide("TAB");
	  coincide("Fin");
	} else {
      error("Eror de sintaxis en <fin_if");
	}
  }
  
  /**
   * (expresion simple) ->
   */
  private void expresionSimple() {
    if (tokenActual.equals("+")) { // -> + (termino) (expresion simple)
      coincide("+");
      termino();
      expresionSimple();
	} else if (tokenActual.equals("-")) { // -> - termino (expresion simple)
      coincide("-");
      termino();
      expresionSimple();
	}
    // con epsilon (e) no hace nada
  }
  
  /**
   * (termino simple) ->
   */
  private void terminoSimple() {
    if (tokenActual.equals("*")) { // -> * (factor) (termino simple)
      coincide("*");
      factor();
      terminoSimple();
	} else if (tokenActual.equals("/")) { // -> (factor) (termino simple)
	  coincide("/");
	  factor();
	  terminoSimple();
	}
    // cuando es epsilon (e) no hace nada
  }
  
  /**
   * Metodo para especificar cual fue el error
   * @param error mensaje de error
   */
  public void error(String error) {
	throw new RuntimeException(error);
  }
  
  /**
   * Metodo para devolver el ultimo token
   * @return el ultimo token
   */
  public String tokenFinal() {
    return tokenActual;
  }
}
