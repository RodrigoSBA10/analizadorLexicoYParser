package Analizadores;

public class Main {

  public static void main(String[] args) {
    String input = "Inicio TAB id ; TAB id := entero ; Fin"; // para las entradas o leer algun txt
    Lexico lexico = new Lexico(input);
    Parser parser = new Parser(lexico);
    try {
      parser.programa(); // Inicia el parser
      System.out.println("Entrada valida");
    } catch (Exception e) {
	  System.out.println("Error: " + e.getMessage());
	}
  }

}
