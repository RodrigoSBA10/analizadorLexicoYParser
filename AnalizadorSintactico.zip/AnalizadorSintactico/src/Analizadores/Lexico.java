package Analizadores;

import java.util.ArrayList;
import java.util.List;

public class Lexico {
  private String entrada;
  private int indice;
  private List<String> tokens;
  
  /** Constructor que recibe la entrar del programa como cadena
   * @param cadena Entrada.
   */
  public Lexico(String cadena) {
    this.entrada = cadena;
    this.indice = 0;
    this .tokens = new ArrayList<>();
    tokens(); // Divido la entrada en tokens
  }
  
  /** Separa la entrda en palabras y añade un token de fin de cadena
   */
  private void tokens() {
    String[] toks = entrada.split("\\s+"); // Divido la entrada pos espacios en blanco
	for (String tok : toks) {
      tokens.add(tok);
	}
	tokens.add("¬"); // Marcador de fin de cadena
  }
  
  /** Para devolver el sigueinte token y avanzar el indice
   * @return siguuiente token (Osea actual)
   */
  public String avanzaSiguienteToken() {
	if (indice < tokens.size()) {
      return tokens.get(indice ++);
	}
	return "¬"; //Si no hay mas devuelve que es el fin de entrada
  }
  
  /** Para devolver el siguiente yoken, pero no avanza el indice
   * @return Token
   */
  public String siguientToken() {
    if(indice < tokens.size()) {
      return tokens.get(indice);
    }
    return "¬"; // Si no hay mas tokens, devuelve el fin de entrada
  }
  
 }
