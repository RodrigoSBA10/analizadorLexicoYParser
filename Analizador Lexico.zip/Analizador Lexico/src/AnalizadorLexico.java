import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Clase para analizar el texto de un archivo y extraer los tokens
 */
public class AnalizadorLexico {
	 // Conjunto de palabras reservadas en set para mejorar la busqueda
	private static final Set<String> palabrasReservadas= new HashSet<>(Arrays.asList("Inicio", "Fin", "Leer", "Escribir", "Si", "Entonces", "Sino", "Mientras", "Hacer"));
	// Cadena que contiene los caracteres especiales
	private static final String caracteresEspeciales="(),;";
	//Expresion regular para identificadores validos (letras seguidas por letras, numeros o guiones bajos)
	private static final Pattern identificador= Pattern.compile("[a-zA-Z][a-zA-Z0-9]*");
	//Expresion regular para reconocer enteros
	private static final Pattern enteros = Pattern.compile("\\d+");
	//Arreglo de operadores relacionales validos
	private static final Set<String> relacionales=new HashSet<>(Arrays.asList(">", "<", "EQ", "LE", "GE"));
	//Cadena de los operadores aritmeticos validos
	private static final String aritmeticos="+-*/";
	//Tabla para almacenar identificadores y palabras reservadas
	private TablaSimbolos tablaSimbolos= new TablaSimbolos();
	//Lista para almacenar los tokens generados
	private List<Token> tokens= new ArrayList<Token>();
	//Lista para almacenar los errores encontrados
	private List<String> errores= new ArrayList<String>();
	//Numero de linea actual
	private int numeroLinea=1;
	/**
	 * Metodo Principal para iniciar el analisis del archivo
	 * @param filename Nombre del archivo
	 * @throws IOException controlador de error
	 */
	public void analizador(String filename)throws IOException {
		//abrir el archico modo lectura
		try(BufferedReader leer = new BufferedReader(new FileReader(filename))){
			int ch;//Variable que almacena el caracter leido del archivo
			//Para acumular caracteres y formar tokens
			StringBuilder procesarToken= new StringBuilder();
			//Manejar comentarios
			boolean comentario=false;
			//Bandera para ignorar caracteres hasta el fin de linea
			boolean ignorarRestoDeLinea=false;
			//Bucle que lee el archivo caracter por caracter
			while ((ch = leer.read()) != -1) {
				char c= (char) ch; //Convierte el valor leido a un caracter
				if(ignorarRestoDeLinea) {
					if(c=='\n') {
						ignorarRestoDeLinea=false;
						numeroLinea++;
					}
					continue;
				}
				//si se encuentra un salto de linea, incrementa el numero de linea
				//System.out.println("Preocesar token contiene: "+procesarToken+"\n c tine: "+c);
				if(c == '\n') {
					numeroLinea++;
					//inicia un comentario
				}else if (c=='{') {
					comentario=true;
					continue;
				}else if (c=='}') {
					//termina un comentario
					comentario=false;
					continue;
				}//si estamos dentro de un comentario, ignora el caracter
				if(comentario)continue;
				//Si el caracter es un espacio, caracter especial o un operador araitmetico
				if (Character.isWhitespace(c) || caracteresEspeciales.indexOf(c) != -1 || aritmeticos.indexOf(c) != -1) {
					//si se ha acumulado un token lo procesa
					if (procesarToken.length() >0) {
						if (processToken(procesarToken.toString())) { 
							ignorarRestoDeLinea=true;//Activa ignorar todo si hubo un error
						} 
						procesarToken.setLength(0); //Reinicia el acumulador de tokens
					}
					//clasificar el caracter y añadir el token correspondiente
					if(caracteresEspeciales.indexOf(c)!= -1) {
						tokens.add(new Token(ClaseToken.CARACTER_ESPECIAL, Character.toString(c)));
					}else if (aritmeticos.indexOf(c) != -1) {
						tokens.add(new Token(ClaseToken.OPERADOR_ARITMETICO, Character.toString(c)));
					}else if (c == '\t') {
						//si es un tabulador, lo registra como token de tabulador
						tokens.add(new Token(ClaseToken.TABULADOR, "\\t"));
					}
				}else if (c == ':') {
					//verifica si el caracter ':' es seguido por '='
					leer.mark(1); //Maeca la posicion acuatl del lector
					char next =(char) leer.read(); //Lee el siguiente caracter
					if (next == '=') {
						if (procesarToken.length()>0) {
							if (processToken(procesarToken.toString())) {
								ignorarRestoDeLinea=true;
							}
							procesarToken.setLength(0);
						}
						tokens.add(new Token(ClaseToken.OPERADOR_ASIGNACION, ":="));
					}else {
						//si el siguien caracter no es '=' regresa el caracter anterior y genera un error
						leer.reset(); //regresa a la posicion marcada
						registrarError(TipoError.CARACTER_NO_VALIDO, ""+c);//Registra un error
						ignorarRestoDeLinea=true;//Activa ignorar resto de linea despues del error
					}
				}else {
					//Acumula el caracter en el StringBuilder
					procesarToken.append(c);
				}
			}
			//Procesa cualquier token restante al final de archivo
			if (procesarToken.length()>0) {
				processToken(procesarToken.toString());
			}
		}
		//Escribe los resultador en archivos
		tablaSimbolos.EscribirFichero("Tabla_Simbolos("+filename+").txt");
		escribirErrores("Errores("+filename+").txt");
		escribirTokens("Tokens("+filename+").txt");
		
	}
	/**
	 * Procesa un token para determinar su tipo y añadirlo a la lista de tokens o errores
	 * @param token token a procesar
	 */
	private boolean processToken(String token) {
		if(token.isEmpty()) return false; //Si el token esta vacio, no hacer nada 
		if (esRelacional(token)) {
			tokens.add(new Token(ClaseToken.OPERADOR_RELACIONAL, token));
		}else if(palabrasReservadas.contains(token)) {
			//Si el token es una palabra reservada
			tablaSimbolos.addSimbolo(token, ClaseToken.PALABRA_RESERVADA);
			tokens.add(new Token(ClaseToken.PALABRA_RESERVADA, Integer.toString(tablaSimbolos.getPosicion(token)),token));
		}else if (esIdentificador(token)){
			//si el token es un identificador
			if (token.length()>10) {
				registrarError(TipoError.LONGITUD_DEL_IDENTIFICADOR_DEMASIADO_LARGO, token);
				return true;
			}else {
				tablaSimbolos.addSimbolo(token, ClaseToken.IDENTIFICADOR);
				tokens.add(new Token(ClaseToken.IDENTIFICADOR, Integer.toString(tablaSimbolos.getPosicion(token)), token));
			}
		}else if (esEntero(token)) {
			//si el token es una constante entera
			int valor= Integer.parseInt(token);
			if(valor<0 || valor >65535) {
				registrarError(TipoError.VALOR_ENTERO_FUERA_DE_RANGO, token);//error de rango
				return true;
			}else {
				tokens.add(new Token(ClaseToken.CONSTANTE_ENTERA, token));
			}
		}else {
			//Maneja los errodes de tipo identificador o caracter
			if(token.matches("^[0-9]+[a-zA-Z_]+.*$")){
				//Si el token no coincide con ningun tipo conocido, se registra como error
				registrarError(TipoError.IDENTIFICADOR_NO_VALIDO, token);
				return true;
			}else {
				registrarError(TipoError.CARACTER_NO_VALIDO, token);
			}
			return true;
		}
		return false;
	}
	/**
	 * Verifica si el token identificador es valido
	 * @param token El token a verificar 
	 * @return true si el token es identificador, false en caso contrario
	 */
	private boolean esIdentificador(String token) {
		return identificador.matcher(token).matches();
	}
	/**
     * Verifica si el token es una constante entera válida
     * @param token El token a verificar
     * @return true si es un entero válido, false si no lo es
     */
	private boolean esEntero(String token) {
		return enteros.matcher(token).matches();
	}
	/**
     * Verifica si el token es un operador relacional válido
     * @param token El token a verificar
     * @return true si es un operador relacional, false si no lo es
     */
	private boolean esRelacional(String token) {
		return relacionales.contains(token);
	}
	/**
     * Registra un error en la lista de errores
     * @param tipo Tipo de error
     * @param token Token que causó el error
     */
	private void registrarError(TipoError tipo, String token) {
		errores.add(new Error(tipo, token, numeroLinea).toString());
	}
	 /**
     * Escribe la lista de tokens en un archivo
     * @param filename Nombre del archivo de salida
     * @throws IOException Controlador de error en caso de fallos en la escritura del archivo
     */
	private void escribirTokens(String nombre)throws IOException{
		try(BufferedWriter escribir= new BufferedWriter(new FileWriter(nombre))){
			//Escribe la cabezera de la tabla de tokens
			escribir.write("Clase | valor\n");
			//Recorre la lista de tokens
			for(Token token: tokens) {
				String valor=token.getValor();
				//Si es identificador o palabra reservada, obtenemos la posicion en la tabla de simbolos
				if(token.getClase() == ClaseToken.IDENTIFICADOR || token.getClase() == ClaseToken.PALABRA_RESERVADA) {
					String id=token.getid();
					//System.out.println(id);
					int posicion =tablaSimbolos.getPosicion(id);
					escribir.write((token.getClase().ordinal()+1)+"\t| "+posicion+"\n");
				}else {
					//Para otros tipos de tokens, escribe el valor solamente
					escribir.write((token.getClase().ordinal()+1)+"\t| "+valor+"\n");
				}
				
			}
		}
	}
	/**
     * Escribe la lista de errores en un archivo
     * @param filename Nombre del archivo de salida
     * @throws IOException Controlador de error en caso de fallos en la escritura del archivo
     */
	private void escribirErrores(String nombre)throws IOException{
		try(BufferedWriter escribir= new BufferedWriter(new FileWriter(nombre))){
			for(String error : errores) {
				escribir.write(error + "\n");
			}
		}
		
	}
}
