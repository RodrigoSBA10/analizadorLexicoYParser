import java.io.*;
import java.util.Map;
import java.util.TreeMap;
public class TablaSimbolos {
	// Mapa que almacena los símbolos (identificadores y palabras reservadas) ordenados alfabéticamente.
	private Map<String, ClaseToken> simbolos= new TreeMap<>();
	// Contador para las posiciones de los símbolos en la tabla.
	private int posicion= 1;
	/**
	 * Agrega un nuevo símbolo a la tabla de símbolos si no ha sido agregado previamente.
	 * 
	 * @param name El nombre del símbolo (identificador o palabra reservada).
	 * @param clase La clase del token al que pertenece el símbolo.
	 */
	public void addSimbolo(String name, ClaseToken clase){
		// Verifica si el símbolo no existe en la tabla antes de agregarlo.
		if (!simbolos.containsKey(name)) {
			simbolos.put(name, clase);
		}
	}
	/**
	 * Obtiene la posición de un símbolo dentro de la tabla de símbolos.
	 * 
	 * @param nombre El nombre del símbolo.
	 * @return La posición del símbolo en la tabla, o -1 si no existe.
	 */
	public int getPosicion(String nombre) {
		int pos=1;
		if (!simbolos.containsKey(nombre)) {
			return -1;
		}
		// Recorre el conjunto de claves del TreeMap en orden alfabético.
		for(String key : simbolos.keySet()) {
			if (key.equals(nombre)) {
				return pos;
			}
			pos++;
		}
		// Si no se encuentra el símbolo, devuelve -1.
		return -1;
	}
	/**
	 * Escribe el contenido de la tabla de símbolos en un archivo.
	 * 
	 * @param fileName El nombre del archivo donde se escribirá la tabla.
	 * @throws IOException Si ocurre un error durante la escritura del archivo.
	 */
	public void EscribirFichero(String fileName)throws IOException{
		try(BufferedWriter escribir= new BufferedWriter(new FileWriter(fileName))){
			// Escribe la cabecera de la tabla.
			escribir.write("Posicion | Nombre | clase \n");
			// Recorre la tabla y escribe cada símbolo con su posición y clase.
			for(Map.Entry<String, ClaseToken> entry : simbolos.entrySet()) {
				escribir.write(posicion++ + "\t| " + entry.getKey() + "\t| " + (entry.getValue().ordinal()+1)+"\n");
			}
		}
	}
}
