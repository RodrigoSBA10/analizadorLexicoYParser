/**
 * Integrantes
 * Hipolito García Axely Aketazli
 * Breña Alvarado Rodrigo Salvador
 */

import java.io.IOException;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		// Crea una instancia del analizador léxico
		AnalizadorLexico analizar=new AnalizadorLexico();
		int opc;
		String archivo="";
		try (Scanner scanner = new Scanner(System.in)) {
			do {
				System.out.println("---- Eleccion de athivo a analizar ----");
				System.out.println("1) Archivo 1");
				System.out.println("2) Archivo 2");
				System.out.println("3) Archivo 3");
				System.out.println("4) Archivo 4");
				System.out.println("5) Archivo 5");
				System.out.println("6) Archivo 6");
				System.out.println("7) Archivo 7");
				System.out.println("8) Archivo 8");
				System.out.println("9) Archivo 9");
				System.out.println("10) Archivo 10");
				System.out.println("11) Archivo propio\n");
				opc=scanner.nextInt();
				switch (opc) {
				case 1: 
					System.out.println("Analizar Archivo 1...");
					archivo="Archivo1.txt";
					break;
				case 2:
					System.out.println("Analizar Archivo 2...");
					archivo="Archivo2.txt";
					break;
				case 3:
					System.out.println("Analizar Archivo 3...");
					archivo="Archivo3.txt";
					break;
				case 4:
					System.out.println("Analizar Archivo 4...");
					archivo="Archivo4.txt";
					break;
				case 5:
					System.out.println("Analizar Archivo 5...");
					archivo="Archivo5.txt";
					break;
				case 6:
					System.out.println("Analizar Archivo 6...");
					archivo="Archivo6.txt";
					break;
				case 7:
					System.out.println("Analizar Archivo 7...");
					archivo="Archivo7.txt";
					break;
				case 8:
					System.out.println("Analizar Archivo 8...");
					archivo="Archivo8.txt";
					break;
				case 9:
					System.out.println("Analizar Archivo 9...");
					archivo="Archivo9.txt";
					break;
				case 10:
					System.out.println("Analizar Archivo 10...");
					archivo="Archivo10.txt";
					break;
				case 11:
					System.out.println("Dame el NOMBRE de tu archivo, recuerda que debe de ser tipo .txt y debe estar dentro de la carpeta del programa\n");
					scanner.nextLine();
					archivo= scanner.nextLine()+".txt";
					break;
				default:
					System.out.println("Opcion no valida, intente de nuevo\npresione enter para volver a ver el menu\n");
					try {
						System.in.read();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					break;
				}
			} while (opc >11);
			scanner.close();
		}
		// Intenta analizar el archivo "Archivo1.txt"
		try {
			// Llama al método que realiza el análisis léxico
			analizar.analizador(archivo);
			System.out.println("Se ha creado el archivo Tabla_Simbolos("+archivo+").txt se encuentra dentro de la carpeta del proyecto 'Analizador Lexico'");
			System.out.println("Se ha creado el archivo Errores("+archivo+").txt se encuentra dentro de la carpeta del proyecto 'Analizador Lexico'");
			System.out.println("Se ha creado el archivo Tokens("+archivo+").txt se encuentra dentro de la carpeta del proyecto 'Analizador Lexico'");
		} catch (Exception e) {
			// Captura y muestra cualquier excepción que ocurra durante el análisis
			e.printStackTrace();
		}
		
	}
}
