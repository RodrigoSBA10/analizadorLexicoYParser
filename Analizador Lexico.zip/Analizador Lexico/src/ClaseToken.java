/**
 * Enumeracion que representa las diferentes clases de tokens que tiene el analizador lexico
 */
public enum ClaseToken {
	PALABRA_RESERVADA, IDENTIFICADOR, CONSTANTE_ENTERA, CARACTER_ESPECIAL,
	OPERADOR_ARITMETICO, OPERADOR_RELACIONAL, OPERADOR_ASIGNACION, TABULADOR
}

