/**
 * Enumeracion que representa los diferentes errores que puede haber a la hora de analizar el archivo
 */
public enum TipoError {
	IDENTIFICADOR_NO_VALIDO, CARACTER_NO_VALIDO, LONGITUD_DEL_IDENTIFICADOR_DEMASIADO_LARGO,
	VALOR_ENTERO_FUERA_DE_RANGO
}
