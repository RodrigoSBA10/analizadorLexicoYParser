/**
 * Clase para representar un error lexico detectado
 */
public class Error {
	//Ripo de error segun la enumeracion
	private TipoError tipo;
	//Valor especifico del token o caracter
	private String valor;
	//La linea del arcihvo donde se encontro el error
	private int linea;
	/**
	 * Constructor que inicializa un error con su tipo, el valor que lo causó y la línea
	 * en la que ocurrió.
	 * 
	 * @param tipo  El tipo de error, representado por la enumeración TipoError.
	 * @param valor El valor específico o token que causó el error.
	 * @param linea El número de línea donde ocurrió el error en el código fuente.
	 */
	public Error(TipoError tipo, String valor, int linea) {
		this.tipo=tipo;
		this.valor=valor;
		this.linea=linea;
	}	
	/**
	 * Método que devuelve una cadena del error.
	 * 
	 * @return Una cadena que describe el error, incluyendo el tipo, el valor y la línea
	 * en la que ocurrió.
	 */
	@Override
	public String toString() {
		return "Error de tipo "+ tipo + ": "+valor + " en linea "+ linea;
	}
}
