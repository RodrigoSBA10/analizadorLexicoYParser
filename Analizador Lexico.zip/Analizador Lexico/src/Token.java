
public class Token {
	// Campo que almacena la clase o tipo del token
	private ClaseToken clase;
	// Campo que almacena el valor del token, es decir, el contenido literal del token 
	private String valor;
	
	private String id;
	/**
     * Constructor de la clase Token
     * @param clase La clase o tipo del token (ej: palabra reservada, identificador)
     * @param valor El valor literal del token (ej: el nombre del identificador o el valor de una constante)
     */
	public Token(ClaseToken clase, String valor) {
		// Asigna el valor del parámetro 'clase' al campo 'clase'
		this.clase=clase;
		// Asigna el valor del parámetro 'valor' al campo 'valor'
		this.valor= valor;
	}
	
	public Token(ClaseToken clase, String valor, String id) {
		this.clase=clase;
		this.valor=valor;
		this.id=id;
	}
	/**
     * Método getter para obtener la clase del token
     * @return La clase o tipo del token
     */
	public ClaseToken getClase() {
		return clase;
	}
	/**
     * Método getter para obtener el valor del token
     * @return El valor literal del token
     */
	public String getValor() {
		return valor;
	}	
	/**
	 * Metodo getter para obtener la cadena en string solo para identificadores y palabras reservadas
	 * @return regresa la cadena del token 
	 */
	public String getid() {
		return id;
	}
}
